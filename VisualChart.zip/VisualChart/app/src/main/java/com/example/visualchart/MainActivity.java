package com.example.visualchart;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.graphics.Matrix;
import android.os.Bundle;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Message;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.view.KeyEvent;

import java.util.Arrays;


public class MainActivity extends AppCompatActivity {
    VisualTest visualTest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Log.d("309", "setContentView(R.layout.activity_main)");
        visualTest = new VisualTest();
        //final VisualTest visualTest = VisualTest.getInstance();
        visualTest.coutTV = (TextView) findViewById(R.id.coutTextview);
        visualTest.rankArr1Tv = (TextView) findViewById(R.id.chart_rank1_tv);
        visualTest.rankArr2Tv = (TextView) findViewById(R.id.chart_rank2_tv);
        visualTest.coutTV = (TextView) findViewById(R.id.coutTextview);
        visualTest.buttonLeft = (Button) findViewById(R.id.left_button);
        visualTest.buttonDown = (Button) findViewById(R.id.down_button);
        visualTest.buttonRight = (Button) findViewById(R.id.right_button);
        visualTest.buttonUp = (Button) findViewById(R.id.up_button);
        visualTest.buttonRes = (Button) findViewById(R.id.restart);
        visualTest.rankSeekBar = (SeekBar) findViewById(R.id.rank_seekb);
        //visualTest.rankSeekBar.setOnSeekBarChangeListener(onSeekBarChangeListener);
        visualTest.chartImgView = (ImageView) findViewById(R.id.cur_chart);
        //Log.d("309", "findviewById");
        // left -> 1       down -> 2         right ->3        up -> 4
        if (!visualTest.checkDisAcc()){
            Log.d("309", "checkDisAcc failed");

        }

        else {
            visualTest.initTest();
            //Log.d("309", "visualTest.initTest()");
            //Log.d("309", "set buttonRes clickListener");

            visualTest.buttonLeft.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    visualTest.judgeChoice(1);
                }
            });

            visualTest.buttonDown.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    visualTest.judgeChoice(2);
                }
            });

            visualTest.buttonRight.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    visualTest.judgeChoice(3);
                }
            });

            visualTest.buttonUp.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    visualTest.judgeChoice(4);
                }
            });

            visualTest.buttonRes.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    visualTest.initTest();
                }
            });
        }



    }


    //

@Override
public boolean onKeyDown(int keyCode, KeyEvent event) {
    if (keyCode == KeyEvent.KEYCODE_DPAD_UP || keyCode == KeyEvent.KEYCODE_DPAD_DOWN
            ||keyCode == KeyEvent.KEYCODE_DPAD_LEFT || keyCode == KeyEvent.KEYCODE_DPAD_RIGHT
            ||keyCode == KeyEvent.KEYCODE_BUTTON_L1 || keyCode == KeyEvent.KEYCODE_BUTTON_R1
            ||keyCode == KeyEvent.KEYCODE_BUTTON_START)
    {
        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_UP:
                Log.d("309", "pressed up");
                //visualTest.coutTV.setText("Pressed up");
                visualTest.buttonUp.performClick();
                break;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                Log.d("309", "pressed down");
                visualTest.buttonDown.performClick();
                break;
            case KeyEvent.KEYCODE_DPAD_LEFT:
                Log.d("309", "pressed left");
                visualTest.buttonLeft.performClick();
                break;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                Log.d("309", "pressed right");
                visualTest.buttonRight.performClick();
                break;
            case KeyEvent.KEYCODE_BUTTON_START:
                Log.d("309", "pressed restart");
                visualTest.buttonRes.performClick();
                break;
            case KeyEvent.KEYCODE_BUTTON_L1:
                //visualTest.coutTV.setText("L1 pressed");
                visualTest.preLineShow();
                break;

            case KeyEvent.KEYCODE_BUTTON_R1:
                //visualTest.coutTV.setText("R1 pressed");
                visualTest.nextLineShow();
                break;
        }
    }
    return true;
}




    /*
    private SeekBar.OnSeekBarChangeListener onSeekBarChangeListener = new SeekBar.OnSeekBarChangeListener() {
        //TextView cout_tv = (TextView) findViewById(R.id.coutTextview);
        @Override
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
            visualTest.setChartRank(seekBar.getProgress());
            visualTest.rankArr1Tv.setText(String.valueOf(visualTest.rankArr1[visualTest.chartRank]));
            visualTest.rankArr2Tv.setText(String.valueOf(visualTest.rankArr2[visualTest.chartRank]));
        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {
        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {
        }

    };
    */




    class VisualTest{
        // left -> 1       down -> 2      right ->3    up -> 4
        public Button buttonLeft;
        public Button buttonDown;
        public Button buttonRight;
        public Button buttonUp;
        public Button buttonRes;
        public TextView rankArr1Tv;
        public TextView rankArr2Tv;
        public TextView coutTV;
        public SeekBar rankSeekBar;
        public ImageView chartImgView;
        // get the resolution of mobile
        public DisplayMetrics dm = getResources().getDisplayMetrics();
        private int scrWidth = dm.widthPixels;
        private int scrHeight = dm.heightPixels;
        private double xdpi = dm.xdpi;
        private double ydpi = dm.ydpi;
        private Bitmap chartMatrix[] = new Bitmap[14]; // rank, row, column
        private final double []chartSizeInchArr = {
                1.43130, 1.13681, 0.90315, 0.71732, 0.56988, 0.45256, 0.35965,
                0.28563, 0.22697, 0.18012, 0.14311, 0.11378, 0.09035, 0.07165
        };

        private double scrWidthInch = scrWidth / xdpi;
        private double scrHeightInch = scrHeight / ydpi;
        private int chartRank;  //from 0 to 13
        private final int lineNum = 14;  // there are 14 lines in all
        private final double []rankArr1 = {4.0, 4.1, 4.2, 4.3, 4.4, 4.5, 4.6, 4.7, 4.8, 4.9,
                5.0, 5.1, 5.2, 5.3};
        private final double []rankArr2 = {0.10, 0.12, 0.15, 0.20, 0.25, 0.30, 0.40, 0.50, 0.60,
                0.80, 1.00, 1.20, 1.50, 2.00};
        private int curDirect;
        private int lastDirect;
        private int nRight;
        private int nWrong;

        public VisualTest(){ }
        public void judgeChoice(int userChoice){
            boolean isRight;
            if(userChoice == curDirect){
                isRight = true;
                nRight++;
            }
            else{
                isRight = false;
                nWrong++;
            }

            // this line is passed
            if (nRight>=3){
                chartRank++;
                // the passed line is not the last line
                if (chartRank<=13){
                    // reset the test state
                    nRight = 0;
                    nWrong = 0;
                    //rankSeekBar.setProgress(chartRank);
                    showChart();
                }
                // the passed line is the last line
                else{
                    chartRank = 13;
                    testOver();
                }
                return;
            }

            // failed to see this line clearly
            if(nWrong>=2){
                chartRank--;
                testOver();
                return;
            }

            // nWrong<2 && nRight<3
            showChart();
        }
        // left -> 1       down -> 2      right ->3    up -> 4
        public void showChart(){
            // create a bit-img object
            Bitmap thisChartBM;
            // random init a direct
            curDirect = 1+(int) (Math.random() * 4);
            // cant' be the same with the last direction
            while(curDirect==lastDirect) {
                curDirect = 1+(int) (Math.random() * 4);
            }
            //curDirect = 1;
            lastDirect = curDirect;
            // 1 2 3 4
            //String chart_file_name = "rank" + String.valueOf(chartRank+1) + "_direc" +
                    //String.valueOf(curDirect);
            //int chartId = getResources().getIdentifier(chart_file_name,"drawable",
                    //"com.example.visualchart");
            //thisChart = BitmapFactory.decodeResource(getResources(), chart_file_name)
            //thisChartBM = BitmapFactory.decodeResource(getResources(), chartId);
            thisChartBM = chartMatrix[chartRank];
            chartImgView.setImageBitmap(thisChartBM);
            // rank1 should be 575 pixel (px) for MI9
            int chartWidthPx = thisChartBM.getWidth();   // px dp  confused
            int charHeightPx = thisChartBM.getHeight();
            chartImgView.setAdjustViewBounds(true);
            chartImgView.setMaxWidth(thisChartBM.getWidth());
            chartImgView.setMaxHeight(thisChartBM.getHeight());
            //chartImgView.setMaxWidth(px2dip(chartWidthPx));
            //chartImgView.setMaxHeight(px2dip(charHeightPx));
            chartImgView.setScaleType(ImageView.ScaleType.FIT_CENTER);
            chartImgView.setRotation((curDirect-1)*270);
            rankSeekBar.setProgress(chartRank);
            rankArr1Tv.setText(String.valueOf(rankArr1[chartRank]));
            rankArr2Tv.setText(String.valueOf(rankArr2[chartRank]));
        }

        public void initTest(){
            // need to gen imgs in this function
            buttonLeft.setVisibility(View.VISIBLE);
            buttonDown.setVisibility(View.VISIBLE);
            buttonRight.setVisibility(View.VISIBLE);
            buttonUp.setVisibility(View.VISIBLE);
            buttonRes.setVisibility(View.VISIBLE);
            //buttonRes.setFocusableInTouchMode(true);
            // setFocusable so the first button pressed will act as I organize
            buttonRes.setFocusable(true);
            chartImgView.setVisibility(View.VISIBLE);
            //rankSeekBar.setVisibility(View.VISIBLE);
            curDirect = 1 + (int) (Math.random() * 3);
            lastDirect = -1;

            nRight = 0;
            nWrong = 0;
            //rankSeekBar.setProgress(0);
            rankSeekBar.setEnabled(false);
            chartRank = 0;
            rankArr1Tv.setText(String.valueOf(rankArr1[chartRank]));
            rankArr2Tv.setText(String.valueOf(rankArr2[chartRank]));
            coutTV.setText("开始测试");
            showChart();

        }

        public void testOver(){
            if(chartRank>=0) {
                coutTV.setText("测试结束 您的视力为：" + String.valueOf(rankArr1[chartRank]));
                //rankSeekBar.setProgress(chartRank);
            }
            else{
                coutTV.setText("测试结束 您的视力小于0.1");
            }
            buttonLeft.setVisibility(View.INVISIBLE);
            buttonDown.setVisibility(View.INVISIBLE);
            buttonRight.setVisibility(View.INVISIBLE);
            buttonUp.setVisibility(View.INVISIBLE);
            chartImgView.setVisibility(View.INVISIBLE);
            //rankSeekBar.setVisibility(View.INVISIBLE);
        }

        public int dip2px(float dpValue) {
            final float scale = getResources().getDisplayMetrics().density;
            return (int) (dpValue * scale + 0.5f);
        }

        public int px2dip (float pxValue) {
            final float scale = getResources().getDisplayMetrics().density;
            return (int) (pxValue / scale + 0.5f);
        }

        public void preLineShow(){
            if (chartRank==0){
                coutTV.setText("已经是第一行了");
            }
            else{
                chartRank--;
                curDirect = 1 + (int) (Math.random() * 3);
                lastDirect = -1;
                nRight = 0;
                nWrong = 0;
                //rankSeekBar.setProgress(chartRank);
                //rankSeekBar.setEnabled(false);
                rankArr1Tv.setText(String.valueOf(rankArr1[chartRank]));
                rankArr2Tv.setText(String.valueOf(rankArr2[chartRank]));
                coutTV.setText("Go to the previous line");
                showChart();
            }
        }

        public void nextLineShow(){
            if (chartRank==13){
                coutTV.setText("已经是最后一行了");
            }
            else{
                chartRank++;
                curDirect = 1 + (int) (Math.random() * 3);
                lastDirect = -1;
                nRight = 0;
                nWrong = 0;
                //rankSeekBar.setProgress(chartRank);
                //rankSeekBar.setEnabled(false);
                rankArr1Tv.setText(String.valueOf(rankArr1[chartRank]));
                rankArr2Tv.setText(String.valueOf(rankArr2[chartRank]));
                coutTV.setText("Go to the next line");
                showChart();
            }
        }

        public void setChartRank(int _rank){
            chartRank = _rank;
        }

        public boolean checkDisAcc(){
            Log.d("309", String.format("scrWidth: %d ", scrWidth).toString());
            Log.d("309", String.format("xdpi: %f ", xdpi).toString());
            Log.d("309", String.format("scrHeight: %d ", scrHeight).toString());
            Log.d("309", String.format("ydpi: %f ", ydpi).toString());
            for(int i = 0; i < 14; i++){
                double curInch = chartSizeInchArr[i];
                double nSizeTheory = curInch*xdpi;
                int nSize = (int)Math.round(nSizeTheory/5)*5;  // int times of 5
                Log.d("309", String.format("%d th chart, nSize:%d nSizeT:%f", i, nSize, nSizeTheory).toString());
                if (Math.abs(nSize - nSizeTheory)/nSizeTheory >= 0.1){
                    coutTV.setText("Display Acc doesn't match!");
                    return false;
                }
                else{
                    if (!genChartBMP(nSize, i)){
                        coutTV.setText("gen BMP failled!");
                        return false;
                    }
                }
            }
            return true;
        }

        public boolean genChartBMP(int _size, int _idx){
            //output_E = zeros(n_pixels, n_pixels);
            //output_E( 1:(4*n_pixels/5), ((n_pixels/5)+1):(2*n_pixels/5)) = 1;
            //output_E( 1:(4*n_pixels/5), ((3*n_pixels/5)+1):(4*n_pixels/5)) = 1;

            // gen left E
            //_size = 575;
            Log.d("309", "_size = 5");
            // set all zero(black)
            chartMatrix[_idx] = Bitmap.createBitmap(_size, _size, Bitmap.Config.ARGB_8888);
            Log.d("309", "init a Bitmap");

            chartMatrix[_idx].eraseColor(Color.parseColor("#000000"));
            Log.d("309", "chartMatrix set zero");


            // turn it to a left E
            for(int i = 0; i < 4*_size/5; i++){
                for(int j = _size/5; j < 2*_size/5; j++){
                    chartMatrix[_idx].setPixel(i, j, 0xFFFFFF);
                }

                for(int j = 3*_size/5; j < 4*_size/5; j++){
                    chartMatrix[_idx].setPixel(i, j, 0xFFFFFF);
                }
            }
            Log.d("309", "left E gened");
            /*
            chartImgView.setImageBitmap(chartMatrix[_idx]);
            // rank1 should be 575 pixel (px) for MI9
            int chartWidthPx = chartMatrix[_idx].getWidth();   // px dp  confused
            int charHeightPx = chartMatrix[_idx].getHeight();
            Log.d("309", String.format("widthpx:%d", chartWidthPx).toString());
            chartImgView.setAdjustViewBounds(true);
            chartImgView.setMaxWidth(chartMatrix[_idx].getWidth());
            chartImgView.setMaxHeight(chartMatrix[_idx].getHeight());
            */
            return true;
        }


    }



}